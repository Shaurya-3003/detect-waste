# FastRCNN (PyTorch) for waste detection

# Implementation
A PyTorch FASTRCNN for detecting waste (TorchVision https://pytorch.org/tutorials/intermediate/torchvision_tutorial.html )

# Dataset
* we use TACO dataset with additional annotated data from detect-waste

# Annotations
* annotations need to be in a csv file. It can be created with json_to_csv notebook.

